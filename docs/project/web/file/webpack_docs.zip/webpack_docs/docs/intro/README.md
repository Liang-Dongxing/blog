# 依赖环境

- Nodejs 16+
