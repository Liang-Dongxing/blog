<template><h1 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍" aria-hidden="true">#</a> 介绍</h1>
<p>本章节我们主要学习：</p>
<ul>
<li>loader 原理</li>
<li>自定义常用 loader</li>
<li>plugin 原理</li>
<li>自定义常用 plugin</li>
</ul>
</template>
