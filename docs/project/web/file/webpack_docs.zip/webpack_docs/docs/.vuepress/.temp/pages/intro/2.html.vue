<template><h1 id="接口文档" tabindex="-1"><a class="header-anchor" href="#接口文档" aria-hidden="true">#</a> 接口文档</h1>
<p>我们提供了在线访问接口文档地址，如下：</p>
<ul>
<li>
<p><a href="http://139.198.34.216:8201/swagger-ui.html" target="_blank" rel="noopener noreferrer">医院管理接口文档<ExternalLinkIcon/></a></p>
</li>
<li>
<p><a href="http://139.198.34.216:8202/swagger-ui.html" target="_blank" rel="noopener noreferrer">数据字典接口文档<ExternalLinkIcon/></a></p>
</li>
<li>
<p><a href="http://139.198.34.216:8203/swagger-ui.html" target="_blank" rel="noopener noreferrer">用户管理接口文档<ExternalLinkIcon/></a></p>
</li>
<li>
<p><a href="http://139.198.34.216:8206/swagger-ui.html" target="_blank" rel="noopener noreferrer">订单管理接口文档<ExternalLinkIcon/></a></p>
</li>
</ul>
</template>
