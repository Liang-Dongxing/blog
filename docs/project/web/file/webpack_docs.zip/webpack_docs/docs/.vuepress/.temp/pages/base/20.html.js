export const data = {
  "key": "v-78589996",
  "path": "/base/20.html",
  "title": "提取 Css 成单独文件",
  "lang": "zh-CN",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "1. 下载包",
      "slug": "_1-下载包",
      "children": []
    },
    {
      "level": 2,
      "title": "2. 配置",
      "slug": "_2-配置",
      "children": []
    },
    {
      "level": 2,
      "title": "3. 运行指令",
      "slug": "_3-运行指令",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "base/20.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
