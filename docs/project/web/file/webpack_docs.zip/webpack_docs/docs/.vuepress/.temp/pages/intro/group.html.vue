<template><h1 id="适合群体" tabindex="-1"><a class="header-anchor" href="#适合群体" aria-hidden="true">#</a> 适合群体</h1>
<ul>
<li><code>Webpack</code> 零基础，想从事项目脚手架研发的人。</li>
<li>具备 <code>Webpack</code> 开发经验，想要提升更多的人。</li>
<li>不是很了解 <code>Webpack</code>，但是想提升工资的人。</li>
</ul>
</template>
