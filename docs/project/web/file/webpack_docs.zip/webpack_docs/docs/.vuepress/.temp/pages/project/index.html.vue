<template><h1 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍" aria-hidden="true">#</a> 介绍</h1>
<p>我们将使用前面所学的知识来从零开始搭建 <code>React-Cli</code> 和 <code>Vue-cli</code>。</p>
</template>
