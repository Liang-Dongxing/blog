<template><h1 id="学习资料" tabindex="-1"><a class="header-anchor" href="#学习资料" aria-hidden="true">#</a> 学习资料</h1>
<ul>
<li>关注 <code>尚硅谷</code> 微信公众号，后台回复 <code>webpack5</code>。</li>
<li>打开 <a href="http://www.bilibili.com/" target="_blank" rel="noopener noreferrer">哔哩哔哩<ExternalLinkIcon/></a> 视频网站，搜索尚硅谷。</li>
</ul>
</template>
