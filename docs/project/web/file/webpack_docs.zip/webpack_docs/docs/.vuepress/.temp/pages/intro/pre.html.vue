<template><h1 id="前置知识" tabindex="-1"><a class="header-anchor" href="#前置知识" aria-hidden="true">#</a> 前置知识</h1>
<ul>
<li>
<p>对 <code>Nodejs</code> 各个核心模块操作有一定认识。</p>
<ul>
<li>比如：<code>fs</code>、<code>path</code>、<code>os</code> 等。</li>
</ul>
</li>
<li>
<p>对 <code>React</code> 和 <code>Vue</code> 有一定认识，并且开发过项目。</p>
<ul>
<li>这对于学习项目部分内容非常有帮助。</li>
</ul>
</li>
</ul>
</template>
