export const pagesData = {
  // path: /
  "v-8daa1a0e": () => import(/* webpackChunkName: "v-8daa1a0e" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/index.html.js").then(({ data }) => data),
  // path: /base/base.html
  "v-a6cc4bba": () => import(/* webpackChunkName: "v-a6cc4bba" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/base.html.js").then(({ data }) => data),
  // path: /base/clean.html
  "v-21f1ba15": () => import(/* webpackChunkName: "v-21f1ba15" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/clean.html.js").then(({ data }) => data),
  // path: /base/config.html
  "v-e703ecdc": () => import(/* webpackChunkName: "v-e703ecdc" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/config.html.js").then(({ data }) => data),
  // path: /base/css.html
  "v-80c5304a": () => import(/* webpackChunkName: "v-80c5304a" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/css.html.js").then(({ data }) => data),
  // path: /base/development.html
  "v-34029aa3": () => import(/* webpackChunkName: "v-34029aa3" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/development.html.js").then(({ data }) => data),
  // path: /base/font.html
  "v-85d4d936": () => import(/* webpackChunkName: "v-85d4d936" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/font.html.js").then(({ data }) => data),
  // path: /base/html.html
  "v-ab115cee": () => import(/* webpackChunkName: "v-ab115cee" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/html.html.js").then(({ data }) => data),
  // path: /base/image.html
  "v-03183b7a": () => import(/* webpackChunkName: "v-03183b7a" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/image.html.js").then(({ data }) => data),
  // path: /base/javascript.html
  "v-0bd200c7": () => import(/* webpackChunkName: "v-0bd200c7" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/javascript.html.js").then(({ data }) => data),
  // path: /base/minifyHtml.html
  "v-50d92e02": () => import(/* webpackChunkName: "v-50d92e02" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/minifyHtml.html.js").then(({ data }) => data),
  // path: /base/optimizeCss.html
  "v-65f7fcd8": () => import(/* webpackChunkName: "v-65f7fcd8" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/optimizeCss.html.js").then(({ data }) => data),
  // path: /base/other.html
  "v-499655ae": () => import(/* webpackChunkName: "v-499655ae" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/other.html.js").then(({ data }) => data),
  // path: /base/output.html
  "v-5a4f3333": () => import(/* webpackChunkName: "v-5a4f3333" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/output.html.js").then(({ data }) => data),
  // path: /base/production.html
  "v-6940ce0a": () => import(/* webpackChunkName: "v-6940ce0a" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/production.html.js").then(({ data }) => data),
  // path: /base/
  "v-1455d425": () => import(/* webpackChunkName: "v-1455d425" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/index.html.js").then(({ data }) => data),
  // path: /base/server.html
  "v-5e3bb631": () => import(/* webpackChunkName: "v-5e3bb631" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/server.html.js").then(({ data }) => data),
  // path: /base/summary.html
  "v-ce2194d0": () => import(/* webpackChunkName: "v-ce2194d0" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/base/summary.html.js").then(({ data }) => data),
  // path: /project/react-cli.html
  "v-61413f94": () => import(/* webpackChunkName: "v-61413f94" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/project/react-cli.html.js").then(({ data }) => data),
  // path: /project/
  "v-c9bbfba2": () => import(/* webpackChunkName: "v-c9bbfba2" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/project/index.html.js").then(({ data }) => data),
  // path: /project/summary.html
  "v-2a04a4a2": () => import(/* webpackChunkName: "v-2a04a4a2" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/project/summary.html.js").then(({ data }) => data),
  // path: /project/vue-cli.html
  "v-04c1b7cf": () => import(/* webpackChunkName: "v-04c1b7cf" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/project/vue-cli.html.js").then(({ data }) => data),
  // path: /origin/loader.html
  "v-1cfd2df6": () => import(/* webpackChunkName: "v-1cfd2df6" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/origin/loader.html.js").then(({ data }) => data),
  // path: /origin/plugin.html
  "v-2d7562d6": () => import(/* webpackChunkName: "v-2d7562d6" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/origin/plugin.html.js").then(({ data }) => data),
  // path: /origin/
  "v-2259a8b0": () => import(/* webpackChunkName: "v-2259a8b0" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/origin/index.html.js").then(({ data }) => data),
  // path: /origin/summary.html
  "v-860cdcba": () => import(/* webpackChunkName: "v-860cdcba" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/origin/summary.html.js").then(({ data }) => data),
  // path: /intro/asset.html
  "v-0670fc65": () => import(/* webpackChunkName: "v-0670fc65" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/intro/asset.html.js").then(({ data }) => data),
  // path: /intro/group.html
  "v-581e5b94": () => import(/* webpackChunkName: "v-581e5b94" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/intro/group.html.js").then(({ data }) => data),
  // path: /intro/learn.html
  "v-7d0ce4de": () => import(/* webpackChunkName: "v-7d0ce4de" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/intro/learn.html.js").then(({ data }) => data),
  // path: /intro/pre.html
  "v-10b408dc": () => import(/* webpackChunkName: "v-10b408dc" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/intro/pre.html.js").then(({ data }) => data),
  // path: /intro/
  "v-f9e30908": () => import(/* webpackChunkName: "v-f9e30908" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/intro/index.html.js").then(({ data }) => data),
  // path: /senior/enhanceExperience.html
  "v-7964f787": () => import(/* webpackChunkName: "v-7964f787" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/senior/enhanceExperience.html.js").then(({ data }) => data),
  // path: /senior/liftingSpeed.html
  "v-7b858f23": () => import(/* webpackChunkName: "v-7b858f23" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/senior/liftingSpeed.html.js").then(({ data }) => data),
  // path: /senior/optimizePerformance.html
  "v-5489448c": () => import(/* webpackChunkName: "v-5489448c" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/senior/optimizePerformance.html.js").then(({ data }) => data),
  // path: /senior/
  "v-3fe9ea34": () => import(/* webpackChunkName: "v-3fe9ea34" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/senior/index.html.js").then(({ data }) => data),
  // path: /senior/reduceVolume.html
  "v-5460e2da": () => import(/* webpackChunkName: "v-5460e2da" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/senior/reduceVolume.html.js").then(({ data }) => data),
  // path: /senior/summary.html
  "v-1d695a4e": () => import(/* webpackChunkName: "v-1d695a4e" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/senior/summary.html.js").then(({ data }) => data),
  // path: /404.html
  "v-3706649a": () => import(/* webpackChunkName: "v-3706649a" */"C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/pages/404.html.js").then(({ data }) => data),
}
