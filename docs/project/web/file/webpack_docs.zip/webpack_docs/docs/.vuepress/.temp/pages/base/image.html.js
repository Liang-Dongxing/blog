export const data = {
  "key": "v-03183b7a",
  "path": "/base/image.html",
  "title": "处理图片资源",
  "lang": "zh-CN",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "1. 配置",
      "slug": "_1-配置",
      "children": []
    },
    {
      "level": 2,
      "title": "2. 添加图片资源",
      "slug": "_2-添加图片资源",
      "children": []
    },
    {
      "level": 2,
      "title": "3. 使用图片资源",
      "slug": "_3-使用图片资源",
      "children": []
    },
    {
      "level": 2,
      "title": "4. 运行指令",
      "slug": "_4-运行指令",
      "children": []
    },
    {
      "level": 2,
      "title": "5. 输出资源情况",
      "slug": "_5-输出资源情况",
      "children": []
    },
    {
      "level": 2,
      "title": "6. 对图片资源进行优化",
      "slug": "_6-对图片资源进行优化",
      "children": []
    }
  ],
  "git": {
    "contributors": [
      {
        "name": "xiongjian",
        "email": "webjsforyou@gmail.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "base/image.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
