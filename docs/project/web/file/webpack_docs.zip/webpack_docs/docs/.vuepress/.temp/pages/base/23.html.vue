<template><h1 id="html-压缩" tabindex="-1"><a class="header-anchor" href="#html-压缩" aria-hidden="true">#</a> html 压缩</h1>
<p>默认生产模式已经开启了：html 压缩和 js 压缩</p>
<p>不需要额外进行配置</p>
</template>
