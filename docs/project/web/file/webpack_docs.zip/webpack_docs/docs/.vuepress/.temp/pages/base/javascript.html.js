export const data = {
  "key": "v-0bd200c7",
  "path": "/base/javascript.html",
  "title": "处理 js 资源",
  "lang": "zh-CN",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "Eslint",
      "slug": "eslint",
      "children": [
        {
          "level": 3,
          "title": "1. 配置文件",
          "slug": "_1-配置文件",
          "children": []
        },
        {
          "level": 3,
          "title": "2. 具体配置",
          "slug": "_2-具体配置",
          "children": []
        },
        {
          "level": 3,
          "title": "3. 在 Webpack 中使用",
          "slug": "_3-在-webpack-中使用",
          "children": []
        },
        {
          "level": 3,
          "title": "4. VSCode Eslint 插件",
          "slug": "_4-vscode-eslint-插件",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "Babel",
      "slug": "babel",
      "children": [
        {
          "level": 3,
          "title": "1. 配置文件",
          "slug": "_1-配置文件-1",
          "children": []
        },
        {
          "level": 3,
          "title": "2. 具体配置",
          "slug": "_2-具体配置-1",
          "children": []
        },
        {
          "level": 3,
          "title": "3. 在 Webpack 中使用",
          "slug": "_3-在-webpack-中使用-1",
          "children": []
        }
      ]
    }
  ],
  "git": {
    "contributors": [
      {
        "name": "xiongjian",
        "email": "webjsforyou@gmail.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "base/javascript.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
