<template><h1 id="我能学到什么" tabindex="-1"><a class="header-anchor" href="#我能学到什么" aria-hidden="true">#</a> 我能学到什么</h1>
<ul>
<li>青铜：我们会学习 <code>Webpack</code> 基础，包含是什么，有什么用，如何使用（这是最重要的）。</li>
<li>黄金：我们会学习 <code>Webpack</code> 高级优化配置，提升项目打包和运行时性能（这也是面试中最常问的点）。</li>
<li>钻石：我们会学习如何从零开始搭建一个项目脚手架，并进行优化（包含 <code>React</code> 和 <code>Vue</code>）。</li>
<li>王者：我们可以学习 <code>Webpack</code> 的原理，这也是迈向大神必备一条路。</li>
</ul>
</template>
